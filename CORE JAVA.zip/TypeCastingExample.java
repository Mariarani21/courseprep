public class TypeCastingExample {
    public static void main(String[] args) {
        double d = 9.78;
        int i = (int) d; // double to int
        System.out.println("Double to Int: " + i);

        int x = 20;
        double y = x; // int to double (implicit)
        System.out.println("Int to Double: " + y);
    }
}

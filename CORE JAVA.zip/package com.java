package com.utils;

public class Util {
    public static String greet(String name) {
        return "Hello, " + name;
    }
}

module com.utils {
    exports com.utils;
}

package com.greetings;

import com.utils.Util;

public class Main {
    public static void main(String[] args) {
        System.out.println(Util.greet("World"));
    }
}

module com.greetings {
    requires com.utils;
}

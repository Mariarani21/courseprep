public class DataTypeDemo {
    public static void main(String[] args) {
        int a = 10;
        float b = 5.5f;
        double c = 20.99;
        char d = 'J';
        boolean e = true;

        System.out.println("int: " + a);
        System.out.println("float: " + b);
        System.out.println("double: " + c);
        System.out.println("char: " + d);
        System.out.println("boolean: " + e);
    }
}

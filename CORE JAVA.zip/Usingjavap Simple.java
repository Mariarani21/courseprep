public class Simple {
    public void sayHello() {
        System.out.println("Hello");
    }
}

let allEvents = [
  { name: "Dance", category: "Music" },
  { name: "Painting", category: "Art" }
];

allEvents.push({ name: "Rock Show", category: "Music" });

const musicEvents = allEvents.filter(e => e.category === "Music");

const formatted = allEvents.map(e => `Workshop: ${e.name}`);
console.log(formatted);

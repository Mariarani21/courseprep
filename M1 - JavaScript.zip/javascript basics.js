// main.js
console.log("Welcome to the Community Portal");

function pageLoaded() {
  alert("Page is fully loaded");
}

document.querySelector("#registerBtn").onclick = function () {
  alert("Registered!");
};

document.querySelector("#categoryFilter").onchange = function (e) {
  console.log("Selected category:", e.target.value);
};

document.addEventListener("keydown", (e) => {
  console.log("Key pressed:", e.key);
});

document.querySelector("#regForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = this.elements["name"].value;
  const email = this.elements["email"].value;
  if (!email.includes("@")) {
    document.querySelector("#error").textContent = "Invalid email";
  } else {
    console.log("Form submitted:", { name, email });
  }
});

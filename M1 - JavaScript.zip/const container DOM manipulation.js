const container = document.querySelector("#eventContainer");

function renderEvent(event) {
  const card = document.createElement("div");
  card.textContent = `${event.name} on ${event.date}`;
  container.appendChild(card);
}

const eventName = "Music Night";
const eventDate = "2025-06-15";
let availableSeats = 30;

console.log(`Event: ${eventName}, Date: ${eventDate}, Seats: ${availableSeats}`);

availableSeats--; // Someone registered
console.log(`Seats left: ${availableSeats}`);

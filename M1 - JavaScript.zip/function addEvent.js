function addEvent(name, date, seats) {
  return { name, date, seats };
}

function registerUser(event) {
  if (event.seats > 0) {
    event.seats--;
    console.log("Registered successfully");
  }
}

function filterEventsByCategory(events, category) {
  return events.filter(e => e.category === category);
}

function registrationCounter() {
  let count = 0;
  return function () {
    count++;
    return count;
  };
}
const countMusic = registrationCounter();

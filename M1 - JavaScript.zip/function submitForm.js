function submitForm(data) {
  fetch("https://mockapi.io/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  })
    .then(res => res.json())
    .then(() => alert("Success!"))
    .catch(() => alert("Failed!"));

  setTimeout(() => {
    console.log("Simulated delay done");
  }, 2000);
}

const events = [
  { name: "Yoga", date: "2025-06-10", seats: 5 },
  { name: "Coding Workshop", date: "2024-01-01", seats: 0 }
];

events.forEach(event => {
  if (new Date(event.date) > new Date() && event.seats > 0) {
    console.log(`Upcoming Event: ${event.name}`);
  }
});

function register(event) {
  try {
    if (event.seats > 0) {
      event.seats--;
      console.log("Registration successful!");
    } else {
      throw "No seats available.";
    }
  } catch (error) {
    console.error("Registration failed:", error);
  }
}

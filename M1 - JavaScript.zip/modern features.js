function greet(name = "Guest") {
  console.log(`Welcome, ${name}`);
}

const event = { name: "Music Fest", date: "2025-07-10" };
const { name, date } = event;

const events = [{ name: "A" }, { name: "B" }];
const clone = [...events];

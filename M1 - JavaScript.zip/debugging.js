console.log("Form submission started");

fetch("https://mockapi.io/register", {
  method: "POST",
  body: JSON.stringify({ name: "Test" })
})
  .then(response => {
    console.log("Payload sent");
    return response.json();
  })
  .then(data => console.log(data))
  .catch(err => console.error("Network error", err));
